from pydantic import BaseModel
class Enquete(BaseModel):
    pergunta:str
