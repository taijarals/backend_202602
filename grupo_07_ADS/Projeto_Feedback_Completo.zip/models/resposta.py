from pydantic import BaseModel
class Resposta(BaseModel):
    enquete_id:int
    aluno_nome:str
    resposta:str
