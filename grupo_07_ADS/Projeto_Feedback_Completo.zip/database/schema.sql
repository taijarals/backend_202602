CREATE TABLE enquetes(id SERIAL PRIMARY KEY, pergunta VARCHAR(255));
CREATE TABLE respostas(id SERIAL PRIMARY KEY, enquete_id INT, aluno_nome VARCHAR(100), resposta VARCHAR(100));