# Projeto Feedback Instantâneo

FastAPI + Streamlit + arquitetura em camadas.
