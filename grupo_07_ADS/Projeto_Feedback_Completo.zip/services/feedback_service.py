class FeedbackService:
    def __init__(self,r): self.r=r
    def listar(self): return self.r.listar()
    def criar(self,d): return self.r.criar(d)
