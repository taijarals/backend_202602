from fastapi import APIRouter
from providers.provider_factory import ProviderFactory
from repositories.feedback_repository import FeedbackRepository
from services.feedback_service import FeedbackService
router=APIRouter(tags=['Feedback'])
svc=FeedbackService(FeedbackRepository(ProviderFactory.create()))
@router.get('/enquetes')
def listar(): return svc.listar()
@router.post('/enquetes')
def criar(enquete:dict): return svc.criar(enquete)
