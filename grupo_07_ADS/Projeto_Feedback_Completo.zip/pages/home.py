import streamlit as st
st.title('EduAtiva')
st.write('Plataforma Educacional')
