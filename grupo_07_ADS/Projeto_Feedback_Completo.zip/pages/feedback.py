import streamlit as st
st.title('Feedback Instantâneo')
pergunta=st.text_input('Pergunta')
if st.button('Criar'): st.success('Criada')
