from providers.supabase_provider import SupabaseProvider
class ProviderFactory:
    @staticmethod
    def create(name='supabase'):
        return SupabaseProvider()
