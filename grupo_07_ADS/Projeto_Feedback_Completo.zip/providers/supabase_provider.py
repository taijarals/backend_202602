from providers.database_provider import DatabaseProvider
class SupabaseProvider(DatabaseProvider):
    def __init__(self): self.data=[]
    def get_all(self,*a,**k): return self.data
    def create(self,obj,*a,**k): self.data.append(obj); return obj
