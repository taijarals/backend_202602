class DatabaseProvider:
    def get_all(self,*a,**k): raise NotImplementedError
    def create(self,*a,**k): raise NotImplementedError
