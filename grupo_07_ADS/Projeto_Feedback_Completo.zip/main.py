from fastapi import FastAPI
from api.feedback_api import router
app=FastAPI(title='EduAtiva API')
app.include_router(router,prefix='/api')
