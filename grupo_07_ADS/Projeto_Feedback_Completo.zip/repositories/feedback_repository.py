class FeedbackRepository:
    def __init__(self,p): self.p=p
    def listar(self): return self.p.get_all()
    def criar(self,d): return self.p.create(d)
