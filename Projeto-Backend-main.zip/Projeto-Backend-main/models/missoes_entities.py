from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class Etapa(BaseModel):
    id: Optional[int] = None
    missao_id: int
    ordem: int # Define a sequência (1, 2, 3...)
    titulo: str
    descricao: str
    pontos_recompensa: int
    conteudo_educacional: str # O material que o aluno deve ler/assistir

class Missao(BaseModel):
    id: Optional[int] = None
    titulo: str
    descricao: str
    professor_id: int
    etapas: List[Etapa] = []

class ProgressoAluno(BaseModel):
    id: Optional[int] = None
    aluno_id: int
    missao_id: int
    etapa_id: int
    data_conclusao: datetime = datetime.now()