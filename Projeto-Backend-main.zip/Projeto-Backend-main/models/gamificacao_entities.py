from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime, date

class HistoricoPontos(BaseModel):
    id: Optional[int] = None
    aluno_id: int
    atividade: str # Ex: "Completou Desafio", "Login Diário"
    pontos: int
    data_registro: datetime = datetime.now()

class Nivel(BaseModel):
    numero: int
    titulo: str
    pontos_necessarios: int

class Medalha(BaseModel):
    id: Optional[int] = None
    nome: str
    descricao: str
    icone: str
    pontos_minimos: int

class PerfilGamificacao(BaseModel):
    aluno_id: int
    pontos_totais: int = 0
    nivel_atual: int = 1
    streak_dias: int = 0
    ultima_atividade: Optional[date] = None
    medalhas: List[Medalha] = []