from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class Aluno(BaseModel):
    id: Optional[int] = None
    nome: str
    email: str

class Professor(BaseModel):
    id: Optional[int] = None
    nome: str
    disciplina_foco: str

class Desafio(BaseModel):
    id: Optional[int] = None
    titulo: str
    descricao: str
    disciplina: str
    prazo: str
    professor_id: int

class Submissao(BaseModel):
    id: Optional[int] = None
    desafio_id: int
    aluno_id: int
    resposta_texto: str
    data_envio: datetime = datetime.now()

class Voto(BaseModel):
    id: Optional[int] = None
    submissao_id: int
    aluno_id: int # Quem votou
    nota: float # Nota de 1.0 a 5.0

class RankingItem(BaseModel):
    desafio_id: int
    submissao_id: int
    aluno_id: int
    media_notas: float