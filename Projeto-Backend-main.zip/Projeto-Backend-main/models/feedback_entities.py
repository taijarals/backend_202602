import streamlit as st
import requests

API_URL = "http://localhost:8000/gamificacao"

st.set_page_config(page_title="Sistema de Gamificação", layout="wide")
st.title("🏆 Sistema de Gamificação")

menu = st.sidebar.radio("Navegação:", ["Meu Perfil Gamificado (Aluno)", "🏆 Ranking Global", "⚙️ Simulador (Adicionar Pontos)"])

if menu == "Meu Perfil Gamificado (Aluno)":
    st.header("Seu Painel de Desempenho")
    aluno_id = st.number_input("Introduza o seu ID de Aluno para ver o perfil:", min_value=1, step=1)
    
    if st.button("Carregar Perfil"):
        res = requests.get(f"{API_URL}/alunos/{aluno_id}")
        if res.status_code == 200:
            perfil = res.json()
            
            # Layout de Dashboard
            col1, col2, col3 = st.columns(3)
            with col1:
                st.metric(label="Nível Atual", value=f"{perfil['nivel_atual']} - {perfil['titulo_nivel']}")
            with col2:
                st.metric(label="Pontos Totais", value=perfil['pontos_totais'])
            with col3:
                st.metric(label="Streak (Dias Seguidos)", value=f"🔥 {perfil['streak_dias']} dias")
            
            st.divider()
            
            # Exibição das Medalhas Conquistadas
            st.subheader("Suas Medalhas 🏅")
            if not perfil['medalhas']:
                st.info("Ainda não conquistou nenhuma medalha. Continue a realizar atividades para ganhar pontos!")
            else:
                cols = st.columns(len(perfil['medalhas']))
                for idx, medalha in enumerate(perfil['medalhas']):
                    with cols[idx]:
                        st.markdown(f"<h1 style='text-align: center;'>{medalha['icone']}</h1>", unsafe_allow_html=True)
                        st.markdown(f"<p style='text-align: center;'><b>{medalha['nome']}</b></p>", unsafe_allow_html=True)
                        st.markdown(f"<p style='text-align: center; font-size: 12px;'>{medalha['descricao']}</p>", unsafe_allow_html=True)
        else:
            st.error("Erro ao carregar perfil.")

elif menu == "🏆 Ranking Global":
    st.header("Ranking dos Melhores Alunos")
    res = requests.get(f"{API_URL}/ranking")
    
    if res.status_code == 200:
        ranking = res.json()
        if not ranking:
            st.info("O ranking ainda está vazio.")
        else:
            for pos, p in enumerate(ranking, start=1):
                icone = "🥇" if pos == 1 else "🥈" if pos == 2 else "🥉" if pos == 3 else "🎗️"
                st.markdown(f"**{pos}º Lugar** {icone} — **Aluno ID:** {p['aluno_id']} | **Nível:** {p['nivel_atual']} | **Pontos:** {p['pontos_totais']}")
    else:
        st.error("Falha ao obter ranking.")

elif menu == "⚙️ Simulador (Adicionar Pontos)":
    st.header("Simulação de Atividades do Sistema")
    st.write("Em produção, este evento ocorreria nos bastidores quando o aluno concluísse um desafio ou mini-prova.")
    
    with st.form("form_pontos"):
        aluno_alvo_id = st.number_input("ID do Aluno Alvo:", min_value=1, step=1)
        atividade = st.selectbox("Atividade Realizada:", ["Concluiu Desafio (+50)", "Gabaritou Mini-Prova (+100)", "Acesso Diário (+10)", "Ajudou no Fórum (+30)"])
        
        # Extrair pontuação do texto usando manipulação simples de string
        pontos = int(atividade.split("(+")[1].split(")")[0])
        
        if st.form_submit_button("Creditar Pontos"):
            payload = {"aluno_id": aluno_alvo_id, "atividade": atividade.split(" (+")[0], "pontos": pontos}
            res = requests.post(f"{API_URL}/pontos", json=payload)
            if res.status_code == 200:
                st.success(f"Foram creditados {pontos} pontos ao Aluno {aluno_alvo_id}!")
            else:
                st.error("Erro ao creditar pontos.")