from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class Questao(BaseModel):
    id: Optional[int] = None
    prova_id: int
    texto: str
    opcao_a: str
    opcao_b: str
    opcao_c: str
    opcao_d: str
    resposta_correta: str  # Ex: 'A', 'B', 'C' ou 'D'

class Prova(BaseModel):
    id: Optional[int] = None
    titulo: str
    professor_id: int
    data_criacao: datetime = datetime.now()

class Tentativa(BaseModel):
    id: Optional[int] = None
    prova_id: int
    aluno_id: int
    inicio: datetime = datetime.now()
    fim: Optional[datetime] = None
    pontuacao: Optional[int] = None

class RespostaAluno(BaseModel):
    questao_id: int
    alternativa_marcada: str

class SubmissaoProva(BaseModel):
    tentativa_id: int
    respostas: List[RespostaAluno]