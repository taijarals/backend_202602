from pydantic import BaseModel
from typing import Optional, List

class PerfilHabilidade(BaseModel):
    aluno_id: int
    nome_aluno: str
    habilidade_principal: str  # Ex: "Programação", "Design", "Liderança", "Comunicação"
    pontuacao_desempenho: float # Nota de 0 a 100 baseada no histórico

class Integrante(BaseModel):
    aluno_id: int
    nome: str
    habilidade: str
    desempenho: float

class Equipa(BaseModel):
    id: Optional[int] = None
    nome: str
    integrantes: List[Integrante] = []
    media_desempenho: float = 0.0

class ConfiguracaoSorteio(BaseModel):
    tamanho_equipa: int
    criterio: str # "Balancear Desempenho" ou "Diversidade de Habilidades"