from repositories.gamificacao_repo import GamificacaoRepository
from models.gamificacao_entities import HistoricoPontos
from datetime import datetime, date, timedelta

class GamificacaoService:
    def __init__(self):
        self.repo = GamificacaoRepository()
        
        # Tabela de Níveis (Hardcoded para performance, mas poderia vir do DB)
        self.tabela_niveis = [
            {"numero": 1, "titulo": "Novato", "pontos": 0},
            {"numero": 2, "titulo": "Aprendiz", "pontos": 100},
            {"numero": 3, "titulo": "Explorador", "pontos": 250},
            {"numero": 4, "titulo": "Especialista", "pontos": 500},
            {"numero": 5, "titulo": "Lenda", "pontos": 1000}
        ]

    def _calcular_nivel(self, pontos_totais: int) -> int:
        nivel_atual = 1
        for nivel in sorted(self.tabela_niveis, key=lambda x: x["pontos"]):
            if pontos_totais >= nivel["pontos"]:
                nivel_atual = nivel["numero"]
        return nivel_atual

    def _atualizar_streak(self, perfil: dict) -> tuple[int, date]:
        hoje = date.today()
        ultima = perfil.get("ultima_atividade")
        streak = perfil.get("streak_dias", 0)

        if ultima is None:
            return 1, hoje
            
        if ultima == hoje:
            return streak, hoje # Já contabilizado hoje
            
        if ultima == hoje - timedelta(days=1):
            return streak + 1, hoje # Sequência mantida
            
        return 1, hoje # Quebrou a sequência

    def _verificar_medalhas(self, pontos_totais: int) -> list:
        todas_medalhas = self.repo.obter_todas_medalhas()
        medalhas_conquistadas = []
        for m in todas_medalhas:
            if pontos_totais >= m["pontos_minimos"]:
                medalhas_conquistadas.append(m)
        return medalhas_conquistadas

    def adicionar_pontos(self, aluno_id: int, atividade: str, pontos: int):
        # 1. Registra o histórico
        hist = HistoricoPontos(aluno_id=aluno_id, atividade=atividade, pontos=pontos)
        self.repo.registrar_pontos(hist.model_dump())
        
        # 2. Recupera e atualiza o perfil
        perfil = self.repo.obter_perfil(aluno_id)
        novos_pontos_totais = perfil["pontos_totais"] + pontos
        
        # 3. Calcula lógicas gamificadas
        novo_nivel = self._calcular_nivel(novos_pontos_totais)
        novo_streak, data_atividade = self._atualizar_streak(perfil)
        novas_medalhas = self._verificar_medalhas(novos_pontos_totais)
        
        # 4. Salva as atualizações
        atualizacoes = {
            "pontos_totais": novos_pontos_totais,
            "nivel_atual": novo_nivel,
            "streak_dias": novo_streak,
            "ultima_atividade": data_atividade,
            "medalhas": novas_medalhas
        }
        return self.repo.atualizar_perfil(aluno_id, atualizacoes)

    def obter_perfil_aluno(self, aluno_id: int):
        perfil = self.repo.obter_perfil(aluno_id)
        # Adiciona o título do nível para o frontend
        titulo_nivel = next((n["titulo"] for n in self.tabela_niveis if n["numero"] == perfil["nivel_atual"]), "Desconhecido")
        perfil["titulo_nivel"] = titulo_nivel
        return perfil

    def obter_ranking_geral(self):
        perfis = self.repo.listar_todos_perfis()
        # Ordena do maior para o menor em pontos totais
        ranking = sorted(perfis, key=lambda x: x["pontos_totais"], reverse=True)
        return ranking