from repositories.desafio_repo import DesafioRepository
from models.entities import Desafio, Submissao, Voto, RankingItem

class DesafioService:
    def __init__(self):
        self.repo = DesafioRepository()

    def criar_novo_desafio(self, desafio: Desafio):
        return self.repo.criar_desafio(desafio.model_dump())

    def obter_todos_desafios(self):
        return self.repo.listar_desafios()

    def enviar_resposta(self, submissao: Submissao):
        return self.repo.criar_submissao(submissao.model_dump())

    def votar_submissao(self, voto: Voto):
        if voto.nota < 1.0 or voto.nota > 5.0:
            raise ValueError("A nota deve estar entre 1.0 e 5.0")
        return self.repo.registrar_voto(voto.model_dump())

    def calcular_media_submissao(self, submissao_id: int) -> float:
        votos = self.repo.listar_votos_por_submissao(submissao_id)
        if not votos:
            return 0.0
        soma = sum(v["nota"] for v in votos)
        return round(soma / len(votos), 2)

    def gerar_ranking(self, desafio_id: int):
        submissoes = self.repo.listar_submissoes_por_desafio(desafio_id)
        ranking = []
        
        for sub in submissoes:
            media = self.calcular_media_submissao(sub["id"])
            item = RankingItem(
                desafio_id=desafio_id,
                submissao_id=sub["id"],
                aluno_id=sub["aluno_id"],
                media_notas=media
            )
            ranking.append(item.model_dump())
            
        # Ordena do maior para o menor (Ranking Geral)
        ranking.sort(key=lambda x: x["media_notas"], reverse=True)
        return ranking