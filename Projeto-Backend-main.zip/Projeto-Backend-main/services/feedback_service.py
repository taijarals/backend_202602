from repositories.feedback_repo import FeedbackRepository
from models.feedback_entities import Enquete, RespostaAluno, EstatisticaPergunta, EstatisticaOpcao

class FeedbackService:
    def __init__(self):
        self.repo = FeedbackRepository()

    def criar_nova_enquete(self, enquete: Enquete):
        return self.repo.criar_enquete(enquete.model_dump())

    def listar_enquetes_ativas(self):
        todas = self.repo.obter_todas_enquetes()
        return [e for e in todas if e["ativa"]]

    def encerrar_enquete(self, enquete_id: int):
        return self.repo.atualizar_status_enquete(enquete_id, ativa=False)

    def submeter_resposta(self, resposta: RespostaAluno):
        enquete = self.repo.obter_enquete(resposta.enquete_id)
        if not enquete:
            raise ValueError("Enquete não encontrada.")
        if not enquete["ativa"]:
            raise ValueError("Esta enquete já foi encerrada pelo professor.")
            
        # Verifica se o aluno já respondeu a esta pergunta (evitar votos duplicados)
        respostas_existentes = self.repo.obter_respostas_por_enquete(resposta.enquete_id)
        if any(r["aluno_id"] == resposta.aluno_id and r["pergunta_id"] == resposta.pergunta_id for r in respostas_existentes):
            raise ValueError("O aluno já respondeu a esta pergunta.")

        return self.repo.registar_resposta(resposta.model_dump())

    def gerar_estatisticas(self, enquete_id: int) -> list[EstatisticaPergunta]:
        enquete = self.repo.obter_enquete(enquete_id)
        if not enquete:
            raise ValueError("Enquete não encontrada.")

        respostas = self.repo.obter_respostas_por_enquete(enquete_id)
        estatisticas = []

        for pergunta in enquete["perguntas"]:
            total_votos_pergunta = 0
            distribuicao = []
            
            for opcao in pergunta["opcoes"]:
                # Conta quantos votos esta opção recebeu
                votos_opcao = sum(1 for r in respostas if r["pergunta_id"] == pergunta["id"] and r["opcao_id"] == opcao["id"])
                distribuicao.append(EstatisticaOpcao(
                    opcao_id=opcao["id"], 
                    texto=opcao["texto"], 
                    quantidade_votos=votos_opcao
                ))
                total_votos_pergunta += votos_opcao
                
            estatisticas.append(EstatisticaPergunta(
                pergunta_id=pergunta["id"],
                texto_pergunta=pergunta["texto"],
                total_votos=total_votos_pergunta,
                distribuicao=distribuicao
            ).model_dump())

        return estatisticas