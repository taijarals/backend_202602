from repositories.equipas_repo import EquipasRepository
from models.equipas_entities import Equipa, Integrante, ConfiguracaoSorteio

class EquipasService:
    def __init__(self):
        self.repo = EquipasRepository()

    def _calcular_media_equipa(self, integrantes: list[Integrante]) -> float:
        if not integrantes:
            return 0.0
        soma = sum(i.desempenho for i in integrantes)
        return round(soma / len(integrantes), 2)

    def gerar_equipas_automaticamente(self, config: ConfiguracaoSorteio) -> list[dict]:
        # 1. Limpa as equipas anteriores (Reorganização)
        self.repo.limpar_equipas()
        
        perfis = self.repo.obter_todos_perfis()
        if not perfis:
            raise ValueError("Não há alunos suficientes para formar equipas.")

        num_equipas = max(1, len(perfis) // config.tamanho_equipa)
        equipas_temp = [[] for _ in range(num_equipas)]

        if config.criterio == "Balancear Desempenho":
            # Ordena do maior desempenho para o menor
            perfis_ordenados = sorted(perfis, key=lambda x: x["pontuacao_desempenho"], reverse=True)
            
            # Algoritmo de Sorteio em Zigue-Zague (Snake Draft) para balancear
            # Passa a distribuir: 1, 2, 3 -> 3, 2, 1 -> 1, 2, 3...
            direcao = 1
            indice_equipa = 0
            
            for perfil in perfis_ordenados:
                equipas_temp[indice_equipa].append(perfil)
                indice_equipa += direcao
                
                # Inverte a direção ao chegar nas pontas
                if indice_equipa >= num_equipas:
                    direcao = -1
                    indice_equipa = num_equipas - 1
                elif indice_equipa < 0:
                    direcao = 1
                    indice_equipa = 0

        elif config.criterio == "Diversidade de Habilidades":
            # Agrupa os alunos por habilidade
            habilidades = {}
            for p in perfis:
                h = p["habilidade_principal"]
                if h not in habilidades:
                    habilidades[h] = []
                habilidades[h].append(p)
            
            # Distribui tentando não repetir habilidades na mesma equipa
            indice_equipa = 0
            for hab, lista_alunos in habilidades.items():
                for aluno in lista_alunos:
                    equipas_temp[indice_equipa].append(aluno)
                    indice_equipa = (indice_equipa + 1) % num_equipas
        else:
            raise ValueError("Critério de formação desconhecido.")

        # 3. Transforma em Entidades e Guarda no Repositório
        resultado_equipas = []
        for i, grupo in enumerate(equipas_temp):
            integrantes = [
                Integrante(aluno_id=p["aluno_id"], nome=p["nome_aluno"], habilidade=p["habilidade_principal"], desempenho=p["pontuacao_desempenho"])
                for p in grupo
            ]
            nova_equipa = Equipa(
                nome=f"Equipa {i + 1}",
                integrantes=integrantes,
                media_desempenho=self._calcular_media_equipa(integrantes)
            )
            salva = self.repo.guardar_equipa(nova_equipa.model_dump())
            resultado_equipas.append(salva)

        return resultado_equipas

    def obter_equipas_atuais(self):
        return self.repo.listar_equipas()
    
    def obter_perfis_alunos(self):
        return self.repo.obter_todos_perfis()