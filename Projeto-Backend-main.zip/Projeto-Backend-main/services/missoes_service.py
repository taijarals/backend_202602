from repositories.missoes_repo import MissoesRepository
from models.missoes_entities import Missao, Etapa, ProgressoAluno

class MissoesService:
    def __init__(self):
        self.repo = MissoesRepository()

    def criar_jornada(self, missao: Missao, etapas: list[Etapa]):
        if not etapas:
            raise ValueError("Uma missão deve ter pelo menos uma etapa.")
            
        missao_salva = self.repo.guardar_missao(missao.model_dump(exclude={"etapas"}))
        etapas_salvas = []
        
        # Guardar etapas associadas à missão
        for etapa in etapas:
            etapa.missao_id = missao_salva["id"]
            salva = self.repo.guardar_etapa(etapa.model_dump())
            etapas_salvas.append(salva)
            
        missao_salva["etapas"] = etapas_salvas
        return missao_salva

    def listar_jornadas_disponiveis(self):
        missoes = self.repo.obter_todas_missoes()
        for m in missoes:
            m["etapas"] = self.repo.obter_etapas_por_missao(m["id"])
        return missoes

    def concluir_etapa(self, aluno_id: int, missao_id: int, etapa_id: int):
        etapas_missao = self.repo.obter_etapas_por_missao(missao_id)
        progresso_atual = self.repo.obter_progresso_aluno(aluno_id, missao_id)
        
        etapas_concluidas_ids = [p["etapa_id"] for p in progresso_atual]
        
        if etapa_id in etapas_concluidas_ids:
            raise ValueError("Esta etapa já foi concluída pelo aluno.")
            
        # Encontrar a etapa a ser concluída
        etapa_alvo = next((e for e in etapas_missao if e["id"] == etapa_id), None)
        if not etapa_alvo:
            raise ValueError("Etapa não encontrada.")

        # Regra de Desbloqueio: Verificar se a etapa anterior foi concluída
        if etapa_alvo["ordem"] > 1:
            etapa_anterior = next((e for e in etapas_missao if e["ordem"] == etapa_alvo["ordem"] - 1), None)
            if etapa_anterior and etapa_anterior["id"] not in etapas_concluidas_ids:
                raise ValueError(f"Acesso Negado. Precisa concluir a Etapa {etapa_anterior['ordem']} primeiro para desbloquear esta.")

        # Regista o progresso
        novo_progresso = ProgressoAluno(aluno_id=aluno_id, missao_id=missao_id, etapa_id=etapa_id)
        registo = self.repo.registar_conclusao_etapa(novo_progresso.model_dump())
        
        # O sistema deve gerar pontuação (Aqui você integraria com o Módulo 3 via API ou Service)
        pontos_ganhos = etapa_alvo["pontos_recompensa"]
        
        return {"mensagem": "Etapa concluída!", "pontos_ganhos": pontos_ganhos, "progresso": registo}
        
    def verificar_status_missao(self, aluno_id: int, missao_id: int):
        etapas = self.repo.obter_etapas_por_missao(missao_id)
        progresso = self.repo.obter_progresso_aluno(aluno_id, missao_id)
        etapas_concluidas = [p["etapa_id"] for p in progresso]
        
        resultado = []
        for e in etapas:
            status = "Bloqueada 🔒"
            if e["id"] in etapas_concluidas:
                status = "Concluída ✅"
            elif e["ordem"] == 1 or (e["ordem"] > 1 and next((x["id"] for x in etapas if x["ordem"] == e["ordem"] - 1), None) in etapas_concluidas):
                status = "Desbloqueada 🔓"
                
            resultado.append({
                "etapa": e,
                "status": status
            })
            
        progresso_percentual = (len(etapas_concluidas) / len(etapas)) * 100 if etapas else 0
        return {"progresso_percentual": round(progresso_percentual, 2), "etapas_status": resultado}