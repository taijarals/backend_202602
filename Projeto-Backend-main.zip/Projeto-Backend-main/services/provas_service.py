from repositories.provas_repo import ProvaRepository
from models.provas_entities import Prova, Questao, Tentativa, SubmissaoProva
from datetime import datetime

class ProvaService:
    def __init__(self):
        self.repo = ProvaRepository()

    def criar_prova_com_questoes(self, prova: Prova, questoes: list[Questao]):
        if len(questoes) != 5:
            raise ValueError("A prova deve conter exatamente 5 questões (Regra de Negócio).")
        
        prova_salva = self.repo.criar_prova(prova.model_dump())
        questoes_salvas = []
        
        for q in questoes:
            q.prova_id = prova_salva["id"]
            questoes_salvas.append(self.repo.adicionar_questao(q.model_dump()))
            
        return {"prova": prova_salva, "questoes": questoes_salvas}

    def listar_todas_provas(self):
        return self.repo.listar_provas()

    def iniciar_tentativa(self, prova_id: int, aluno_id: int):
        # Valida se a prova existe
        questoes = self.repo.listar_questoes_por_prova(prova_id)
        if not questoes:
            raise ValueError("Prova não encontrada ou sem questões.")
            
        tentativa = Tentativa(prova_id=prova_id, aluno_id=aluno_id)
        return self.repo.registrar_tentativa(tentativa.model_dump())

    def obter_questoes_para_aluno(self, prova_id: int):
        # Oculta as respostas corretas antes de enviar ao frontend
        questoes = self.repo.listar_questoes_por_prova(prova_id)
        questoes_seguras = []
        for q in questoes:
            q_segura = q.copy()
            q_segura.pop("resposta_correta", None)
            questoes_seguras.append(q_segura)
        return questoes_seguras

    def submeter_prova_e_corrigir(self, submissao: SubmissaoProva):
        tentativa = self.repo.obter_tentativa(submissao.tentativa_id)
        if not tentativa:
            raise ValueError("Tentativa não encontrada.")
        
        if tentativa["fim"] is not None:
            raise ValueError("Esta tentativa já foi finalizada.")

        tempo_fim = datetime.now()
        tempo_decorrido = (tempo_fim - tentativa["inicio"]).total_seconds()
        
        # Regra de 5 minutos totais + 10 segundos de tolerância de rede
        limite_segundos = (5 * 60) + 10
        if tempo_decorrido > limite_segundos:
            self.repo.atualizar_tentativa(submissao.tentativa_id, {"fim": tempo_fim, "pontuacao": 0})
            raise ValueError("Tempo esgotado! Sua prova foi zerada (limite de 5 minutos).")

        # Correção Automática
        pontos = 0
        questoes_banco = self.repo.listar_questoes_por_prova(tentativa["prova_id"])
        mapa_respostas_corretas = {q["id"]: q["resposta_correta"] for q in questoes_banco}

        for resp in submissao.respostas:
            correta = mapa_respostas_corretas.get(resp.questao_id)
            if correta and resp.alternativa_marcada == correta:
                pontos += 1  # 1 ponto por questão, total 5

        # Atualiza a tentativa com o resultado
        tentativa_atualizada = self.repo.atualizar_tentativa(
            submissao.tentativa_id, 
            {"fim": tempo_fim, "pontuacao": pontos}
        )
        return tentativa_atualizada