from providers.database import DatabaseProvider

class MockProvider(DatabaseProvider):
    def __init__(self):
        self._data = []

    def get_all(self):
        return self._data

    def create(self, data):
        self._data.append(data)
        return data

class ProviderFactory:
    @staticmethod
    def create(strategy: str) -> DatabaseProvider:
        if strategy == "mock":
            return MockProvider()
        # Aqui você pode adicionar "sql" ou "supabase" no futuro
        raise ValueError("Estratégia de provider não suportada.")