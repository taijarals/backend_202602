from abc import ABC, abstractmethod

class DatabaseProvider(ABC):
    @abstractmethod
    def get_all(self):
        pass

    @abstractmethod
    def create(self, data):
        pass