import streamlit as st
import requests

API_URL = "http://localhost:8000/missoes"

st.set_page_config(page_title="Missões Educacionais", layout="wide")
st.title("🗺️ Jornadas de Aprendizagem (Missões)")

perfil = st.sidebar.radio("Selecione o seu Perfil:", ["👨‍🏫 Professor", "👨‍🎓 Aluno"])

if perfil == "👨‍🏫 Professor":
    st.header("Criar Nova Missão Educacional")
    st.write("Crie uma jornada passo a passo para os seus alunos.")
    
    with st.form("form_criar_missao"):
        titulo_missao = st.text_input("Título da Missão Maior (ex: Jornada do Python)")
        desc_missao = st.text_area("Descrição da Missão")
        prof_id = st.number_input("O seu ID de Professor", min_value=1, step=1)
        
        st.subheader("Etapas (Passos a Desbloquear)")
        qtd_etapas = st.slider("Quantas etapas terá esta missão?", 1, 5, 3)
        
        etapas_lista = []
        for i in range(1, qtd_etapas + 1):
            st.markdown(f"**Etapa {i}**")
            t_etapa = st.text_input(f"Título da Etapa {i}")
            c_etapa = st.text_area(f"Conteúdo/Tarefa da Etapa {i}")
            pts_etapa = st.number_input(f"Pontos Recompensa (Etapa {i})", min_value=10, step=10)
            
            etapas_lista.append({
                "ordem": i, "titulo": t_etapa, "descricao": "Passo obrigatório",
                "conteudo_educacional": c_etapa, "pontos_recompensa": pts_etapa, "missao_id": 0
            })
            st.divider()
            
        if st.form_submit_button("Lançar Missão"):
            payload = {
                "missao": {"titulo": titulo_missao, "descricao": desc_missao, "professor_id": prof_id},
                "etapas": etapas_lista
            }
            res = requests.post(f"{API_URL}/", json=payload)
            if res.status_code == 200:
                st.success("Jornada criada com sucesso! Os alunos já podem iniciar a missão.")
            else:
                st.error("Erro ao criar a missão.")

elif perfil == "👨‍🎓 Aluno":
    st.header("O Seu Mapa de Missões")
    aluno_id = st.number_input("Introduza o seu ID de Aluno:", min_value=1, step=1)
    
    missoes_res = requests.get(f"{API_URL}/")
    if missoes_res.status_code == 200 and missoes_res.json():
        missoes = missoes_res.json()
        opcoes = {m["id"]: m["titulo"] for m in missoes}
        escolha = st.selectbox("Selecione uma Jornada para Iniciar:", options=list(opcoes.keys()), format_func=lambda x: opcoes[x])
        
        if escolha:
            st.divider()
            status_res = requests.get(f"{API_URL}/status?aluno_id={aluno_id}&missao_id={escolha}")
            
            if status_res.status_code == 200:
                dados_status = status_res.json()
                st.progress(dados_status["progresso_percentual"] / 100)
                st.write(f"**Progresso na Missão:** {dados_status['progresso_percentual']}%")
                
                for item in dados_status["etapas_status"]:
                    etapa = item["etapa"]
                    status = item["status"]
                    
                    with st.expander(f"Etapa {etapa['ordem']}: {etapa['titulo']} - {status}", expanded=(status == "Desbloqueada 🔓")):
                        if status == "Bloqueada 🔒":
                            st.warning("Tem de concluir a etapa anterior para desbloquear este conteúdo.")
                        else:
                            st.write(f"**Recompensa:** {etapa['pontos_recompensa']} Pontos 🏆")
                            st.info(etapa["conteudo_educacional"])
                            
                            if status == "Desbloqueada 🔓":
                                if st.button(f"Concluir Etapa {etapa['ordem']}", key=f"btn_concluir_{etapa['id']}"):
                                    res_concluir = requests.post(f"{API_URL}/progresso?aluno_id={aluno_id}&missao_id={escolha}&etapa_id={etapa['id']}")
                                    if res_concluir.status_code == 200:
                                        resultado = res_concluir.json()
                                        st.success(f"Excelente! {resultado['mensagem']} Ganhou {resultado['pontos_ganhos']} pontos!")
                                        st.rerun()
                                    else:
                                        st.error(f"Aviso: {res_concluir.json().get('detail')}")
                            else:
                                st.success("Já concluiu esta etapa!")
    else:
        st.info("Não há missões disponíveis de momento.")