import streamlit as st
import requests
from datetime import datetime

API_URL = "http://localhost:8000/mini-provas"

st.set_page_config(page_title="Mini-Provas Gamificadas", layout="wide")
st.title("⏱️ Sistema de Mini-Provas")

perfil = st.sidebar.radio("Selecione seu Perfil:", ["👨‍🏫 Professor", "👨‍🎓 Aluno"])

if perfil == "👨‍🏫 Professor":
    st.header("Cadastrar Nova Prova")
    st.info("Regra Obrigatória: Toda prova deve conter exatamente 5 questões (1 minuto por questão).")
    
    with st.form("form_criar_prova"):
        titulo = st.text_input("Título da Prova")
        prof_id = st.number_input("Seu ID de Professor", min_value=1, step=1)
        
        st.subheader("Questões")
        questoes = []
        for i in range(1, 6):
            st.markdown(f"**Questão {i}**")
            texto = st.text_input(f"Enunciado {i}", key=f"texto_{i}")
            col1, col2, col3, col4 = st.columns(4)
            with col1: op_a = st.text_input("A", key=f"a_{i}")
            with col2: op_b = st.text_input("B", key=f"b_{i}")
            with col3: op_c = st.text_input("C", key=f"c_{i}")
            with col4: op_d = st.text_input("D", key=f"d_{i}")
            correta = st.selectbox("Correta", ["A", "B", "C", "D"], key=f"corr_{i}")
            
            questoes.append({
                "prova_id": 0, "texto": texto, "opcao_a": op_a, "opcao_b": op_b, 
                "opcao_c": op_c, "opcao_d": op_d, "resposta_correta": correta
            })
            st.divider()

        if st.form_submit_button("Salvar Prova Completa"):
            payload = {
                "titulo": titulo, "professor_id": prof_id, "questoes": questoes
            }
            res = requests.post(f"{API_URL}/", json=payload)
            if res.status_code == 200:
                st.success("Prova e questões criadas com sucesso!")
            else:
                st.error(f"Erro: {res.json().get('detail')}")

elif perfil == "👨‍🎓 Aluno":
    st.header("Avaliações Disponíveis")
    
    provas_res = requests.get(f"{API_URL}/")
    provas = provas_res.json() if provas_res.status_code == 200 else []
    
    if not provas:
        st.info("Nenhuma prova disponível no momento.")
    else:
        opcoes = {p["id"]: p["titulo"] for p in provas}
        prova_selecionada = st.selectbox("Escolha uma prova:", options=list(opcoes.keys()), format_func=lambda x: opcoes[x])
        aluno_id = st.number_input("Seu ID de Aluno", min_value=1, step=1)
        
        if "tentativa_id" not in st.session_state:
            st.session_state.tentativa_id = None
            
        if st.session_state.tentativa_id is None:
            if st.button("▶️ Iniciar Prova (Cronômetro será ativado)"):
                res_inicio = requests.post(f"{API_URL}/tentativas/?prova_id={prova_selecionada}&aluno_id={aluno_id}")
                if res_inicio.status_code == 200:
                    st.session_state.tentativa_id = res_inicio.json()["id"]
                    st.rerun()
        else:
            st.warning("⏱️ Você tem 5 minutos totais para enviar suas respostas a partir de agora!")
            questoes_res = requests.get(f"{API_URL}/{prova_selecionada}/questoes")
            questoes = questoes_res.json()
            
            with st.form("form_respostas"):
                respostas_aluno = []
                for q in questoes:
                    st.write(f"**{q['texto']}**")
                    escolha = st.radio(
                        "Selecione a alternativa:", 
                        [f"A) {q['opcao_a']}", f"B) {q['opcao_b']}", f"C) {q['opcao_c']}", f"D) {q['opcao_d']}"],
                        key=f"q_{q['id']}"
                    )
                    respostas_aluno.append({
                        "questao_id": q["id"],
                        "alternativa_marcada": escolha.split(")")[0] # Pega apenas a letra 'A', 'B', etc.
                    })
                    st.divider()
                
                if st.form_submit_button("Submeter Prova"):
                    payload_sub = {
                        "tentativa_id": st.session_state.tentativa_id,
                        "respostas": respostas_aluno
                    }
                    res_sub = requests.post(f"{API_URL}/submissoes/", json=payload_sub)
                    
                    if res_sub.status_code == 200:
                        resultado = res_sub.json()
                        st.success(f"Prova finalizada! Sua pontuação: {resultado['pontuacao']}/5")
                        st.session_state.tentativa_id = None # Reseta para próxima prova
                    else:
                        st.error(f"Falha na entrega: {res_sub.json().get('detail')}")
                        st.session_state.tentativa_id = None # Reseta em caso de falha (ex: timeout)