import streamlit as st
import requests
import pandas as pd

API_URL = "http://localhost:8000/feedback"

st.set_page_config(page_title="Feedback Instantâneo", layout="wide")
st.title("📊 Sistema de Feedback Instantâneo")

perfil = st.sidebar.radio("Selecione o seu Perfil:", ["👨‍🏫 Professor", "👨‍🎓 Aluno"])

if perfil == "👨‍🏫 Professor":
    aba1, aba2 = st.tabs(["Criar Nova Sondagem (Enquete)", "Visualizar Resultados em Tempo Real"])
    
    with aba1:
        st.subheader("Criar Pergunta Rápida")
        with st.form("form_enquete"):
            titulo = st.text_input("Título / Tópico da Aula")
            prof_id = st.number_input("O seu ID de Professor", min_value=1, step=1)
            pergunta_texto = st.text_input("A sua Pergunta (ex: Compreenderam o conceito?)")
            
            st.write("Opções de Resposta:")
            col1, col2, col3 = st.columns(3)
            with col1: op1 = st.text_input("Opção 1", value="Sim, perfeitamente.")
            with col2: op2 = st.text_input("Opção 2", value="Mais ou menos.")
            with col3: op3 = st.text_input("Opção 3", value="Não entendi nada.")
            
            if st.form_submit_button("Lançar Sondagem para a Turma"):
                payload = {
                    "titulo": titulo,
                    "professor_id": prof_id,
                    "ativa": True,
                    "perguntas": [
                        {
                            "texto": pergunta_texto,
                            "opcoes": [{"texto": op1}, {"texto": op2}, {"texto": op3}]
                        }
                    ]
                }
                res = requests.post(f"{API_URL}/enquetes", json=payload)
                if res.status_code == 200:
                    st.success("Sondagem lançada! Os alunos já podem votar.")
                else:
                    st.error("Erro ao criar sondagem.")
                    
    with aba2:
        st.subheader("Painel de Estatísticas e Gráficos")
        if st.button("Atualizar Dados 🔄"):
            pass # O botão força a recarga do Streamlit

        # Vamos buscar as ativas (no protótipo assumimos que lista todas para o prof)
        res_enq = requests.get(f"{API_URL}/enquetes/ativas")
        if res_enq.status_code == 200 and res_enq.json():
            enquetes = res_enq.json()
            opcoes_enq = {e["id"]: e["titulo"] for e in enquetes}
            enq_selecionada = st.selectbox("Escolha a Sondagem:", options=list(opcoes_enq.keys()), format_func=lambda x: opcoes_enq[x])
            
            # Obtém estatísticas
            res_stats = requests.get(f"{API_URL}/enquetes/{enq_selecionada}/estatisticas")
            if res_stats.status_code == 200:
                stats = res_stats.json()
                for stat in stats:
                    st.markdown(f"**Pergunta:** {stat['texto_pergunta']} (Total de Votos: {stat['total_votos']})")
                    
                    # Prepara dados para o gráfico do Streamlit
                    if stat['total_votos'] > 0:
                        df = pd.DataFrame(stat['distribuicao'])
                        df = df.set_index('texto')
                        st.bar_chart(df['quantidade_votos'])
                    else:
                        st.info("Aguardando os votos dos alunos...")
            
            if st.button("Encerrar Sondagem"):
                requests.put(f"{API_URL}/enquetes/{enq_selecionada}/encerrar")
                st.warning("Sondagem encerrada!")
                st.rerun()
        else:
            st.write("Não há sondagens ativas no momento.")

elif perfil == "👨‍🎓 Aluno":
    st.header("Responder a Sondagens Ativas")
    aluno_id = st.number_input("O seu ID de Aluno:", min_value=1, step=1)
    
    res = requests.get(f"{API_URL}/enquetes/ativas")
    if res.status_code == 200:
        enquetes = res.json()
        if not enquetes:
            st.info("Nenhuma sondagem ativa neste momento. Preste atenção à aula! 👨‍🏫")
        else:
            for e in enquetes:
                with st.expander(f"📌 {e['titulo']}", expanded=True):
                    with st.form(f"form_voto_{e['id']}"):
                        respostas = {}
                        for p in e["perguntas"]:
                            st.write(f"**{p['texto']}**")
                            # Cria as opções no formato para o radio button
                            opcoes_dict = {o["id"]: o["texto"] for o in p["opcoes"]}
                            escolha = st.radio("Selecione:", options=list(opcoes_dict.keys()), format_func=lambda x: opcoes_dict[x], key=f"p_{p['id']}")
                            respostas[p["id"]] = escolha
                        
                        if st.form_submit_button("Enviar Resposta"):
                            for p_id, op_id in respostas.items():
                                payload_voto = {
                                    "enquete_id": e["id"],
                                    "pergunta_id": p_id,
                                    "opcao_id": op_id,
                                    "aluno_id": aluno_id
                                }
                                v_res = requests.post(f"{API_URL}/respostas", json=payload_voto)
                                if v_res.status_code == 200:
                                    st.success("Voto registado com sucesso!")
                                else:
                                    st.error(f"Aviso: {v_res.json().get('detail')}")