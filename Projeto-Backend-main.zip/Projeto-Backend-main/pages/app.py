import streamlit as st
import requests

API_URL = "http://localhost:8000"

st.set_page_config(page_title="Módulo de Desafios", layout="wide")

st.sidebar.title("Navegação")
perfil = st.sidebar.radio("Selecione seu Perfil:", ["👨‍🏫 Professor", "👨‍🎓 Aluno"])

if perfil == "👨‍🏫 Professor":
    st.title("Painel do Professor")
    aba1, aba2 = st.tabs(["Cadastrar Desafio", "Visualizar Ranking"])
    
    with aba1:
        st.subheader("Novo Desafio")
        with st.form("form_novo_desafio"):
            titulo = st.text_input("Título")
            desc = st.text_area("Descrição")
            disciplina = st.text_input("Disciplina")
            prazo = st.date_input("Prazo final")
            prof_id = st.number_input("Seu ID de Professor", min_value=1, step=1)
            
            if st.form_submit_button("Salvar Desafio"):
                payload = {"titulo": titulo, "descricao": desc, "disciplina": disciplina, "prazo": str(prazo), "professor_id": prof_id}
                res = requests.post(f"{API_URL}/desafios/", json=payload)
                if res.status_code == 200:
                    st.success("Desafio salvo com sucesso!")
                    
    with aba2:
        st.subheader("Ranking por Desafio")
        desafios_res = requests.get(f"{API_URL}/desafios/")
        if desafios_res.status_code == 200 and desafios_res.json():
            desafios = desafios_res.json()
            opcoes = {d["id"]: f"ID: {d['id']} - {d['titulo']}" for d in desafios}
            escolha = st.selectbox("Selecione o Desafio", options=list(opcoes.keys()), format_func=lambda x: opcoes[x])
            
            if st.button("Carregar Ranking"):
                rank_res = requests.get(f"{API_URL}/desafios/{escolha}/ranking")
                if rank_res.status_code == 200:
                    st.table(rank_res.json())
        else:
            st.info("Nenhum desafio encontrado.")

elif perfil == "👨‍🎓 Aluno":
    st.title("Painel do Aluno")
    aba1, aba2 = st.tabs(["Responder Desafios", "Votar em Respostas"])
    
    desafios_res = requests.get(f"{API_URL}/desafios/")
    desafios = desafios_res.json() if desafios_res.status_code == 200 else []
    
    with aba1:
        st.subheader("Desafios Abertos")
        if not desafios:
            st.info("Não há desafios abertos.")
        for d in desafios:
            with st.expander(f"{d['titulo']} (Prazo: {d['prazo']})"):
                st.write(d["descricao"])
                with st.form(f"form_sub_{d['id']}"):
                    aluno_id = st.number_input("Seu ID de Aluno", min_value=1, step=1, key=f"aluno_{d['id']}")
                    resposta = st.text_area("Sua Resposta", key=f"resp_{d['id']}")
                    if st.form_submit_button("Enviar Resposta"):
                        payload = {"desafio_id": d["id"], "aluno_id": aluno_id, "resposta_texto": resposta}
                        res = requests.post(f"{API_URL}/submissoes/", json=payload)
                        if res.status_code == 200:
                            st.success("Resposta enviada!")
                            
    with aba2:
        st.subheader("Sistema de Votação")
        st.write("Avalie as submissões de outros alunos para gerar o ranking!")
        # Simplificação para o escopo do protótipo: avaliando por ID de submissão.
        with st.form("form_voto"):
            sub_id = st.number_input("ID da Submissão", min_value=1, step=1)
            aluno_votante_id = st.number_input("Seu ID de Aluno (Avaliador)", min_value=1, step=1)
            nota = st.slider("Nota", 1.0, 5.0, 3.0, 0.5)
            
            if st.form_submit_button("Registrar Voto"):
                payload = {"submissao_id": sub_id, "aluno_id": aluno_votante_id, "nota": nota}
                res = requests.post(f"{API_URL}/votos/", json=payload)
                if res.status_code == 200:
                    st.success("Voto computado com sucesso! A média será atualizada.")
                else:
                    st.error("Erro ao registrar voto.")