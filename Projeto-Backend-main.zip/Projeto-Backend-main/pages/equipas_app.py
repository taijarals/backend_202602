import streamlit as st
import requests

API_URL = "http://localhost:8000/equipas"

st.set_page_config(page_title="Formação de Equipas", layout="wide")
st.title("🤝 Sistema de Formação Automática de Equipas")

aba1, aba2 = st.tabs(["Painel do Professor (Gerir Equipas)", "Visão do Aluno (A Minha Equipa)"])

with aba1:
    st.subheader("Configurar Geração de Equipas")
    
    col1, col2 = st.columns(2)
    with col1:
        criterio = st.selectbox("Critério de Agrupamento:", ["Balancear Desempenho", "Diversidade de Habilidades"])
    with col2:
        tamanho = st.number_input("Alunos por Equipa:", min_value=2, max_value=10, value=3)
        
    st.info("A opção 'Balancear Desempenho' garante que a média de notas de cada equipa seja muito próxima. A 'Diversidade' evita repetir a mesma habilidade na mesma equipa.")

    if st.button("Gerar / Reorganizar Equipas ⚙️", type="primary"):
        payload = {"tamanho_equipa": tamanho, "criterio": criterio}
        res = requests.post(f"{API_URL}/gerar", json=payload)
        
        if res.status_code == 200:
            st.success("Equipas geradas com sucesso!")
        else:
            st.error(f"Erro: {res.json().get('detail')}")

    st.divider()
    
    st.subheader("Equipas Atuais Formadas")
    equipas_res = requests.get(f"{API_URL}/")
    if equipas_res.status_code == 200 and equipas_res.json():
        equipas = equipas_res.json()
        cols = st.columns(len(equipas) if len(equipas) > 0 else 1)
        
        for idx, equipa in enumerate(equipas):
            with cols[idx % len(cols)]: # Proteção se houver muitas equipas
                st.markdown(f"### {equipa['nome']}")
                st.metric(label="Média de Desempenho do Grupo", value=f"{equipa['media_desempenho']}/100")
                for integrante in equipa['integrantes']:
                    st.markdown(f"- **{integrante['nome']}** (*{integrante['habilidade']}* | Nota: {integrante['desempenho']})")
    else:
        st.write("Ainda não foram formadas equipas.")

with aba2:
    st.subheader("Descubra a sua Equipa")
    aluno_id = st.number_input("Introduza o seu ID de Aluno:", min_value=1, step=1, key="id_aluno_pesquisa")
    
    if st.button("Procurar a minha Equipa"):
        equipas_res = requests.get(f"{API_URL}/")
        equipas = equipas_res.json() if equipas_res.status_code == 200 else []
        
        equipa_encontrada = None
        para_o_aluno = None
        
        for eq in equipas:
            for intr in eq["integrantes"]:
                if intr["aluno_id"] == aluno_id:
                    equipa_encontrada = eq
                    para_o_aluno = intr
                    break
        
        if equipa_encontrada:
            st.success(f"Você pertence à **{equipa_encontrada['nome']}**!")
            st.write(f"O seu papel sugerido para o grupo baseia-se na sua habilidade forte: **{para_o_aluno['habilidade']}**.")
            st.write("**Os seus colegas de equipa são:**")
            for colega in equipa_encontrada["integrantes"]:
                if colega["aluno_id"] != aluno_id:
                    st.markdown(f"👤 {colega['nome']} - {colega['habilidade']}")
        else:
            st.warning("Ainda não foi alocado a nenhuma equipa. Aguarde que o professor realize o sorteio.")