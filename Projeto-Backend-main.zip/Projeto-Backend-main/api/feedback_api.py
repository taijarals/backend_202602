from fastapi import APIRouter, HTTPException
from typing import List, Dict
from models.feedback_entities import Enquete, RespostaAluno
from services.feedback_service import FeedbackService

router = APIRouter(prefix="/feedback", tags=["Feedback Instantâneo"])
service = FeedbackService()

@router.post("/enquetes", response_model=Dict)
def criar_enquete(enquete: Enquete):
    return service.criar_nova_enquete(enquete)

@router.get("/enquetes/ativas", response_model=List[Dict])
def listar_ativas():
    return service.listar_enquetes_ativas()

@router.put("/enquetes/{enquete_id}/encerrar")
def fechar_enquete(enquete_id: int):
    return service.encerrar_enquete(enquete_id)

@router.post("/respostas", response_model=Dict)
def registar_voto_aluno(resposta: RespostaAluno):
    try:
        return service.submeter_resposta(resposta)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/enquetes/{enquete_id}/estatisticas")
def obter_graficos(enquete_id: int):
    try:
        return service.gerar_estatisticas(enquete_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))