from fastapi import APIRouter, HTTPException
from typing import List, Dict
from pydantic import BaseModel
from services.gamificacao_service import GamificacaoService

router = APIRouter(prefix="/gamificacao", tags=["Gamificação"])
service = GamificacaoService()

class PayloadPontos(BaseModel):
    aluno_id: int
    atividade: str
    pontos: int

@router.post("/pontos", response_model=Dict)
def creditar_pontos(payload: PayloadPontos):
    try:
        return service.adicionar_pontos(payload.aluno_id, payload.atividade, payload.pontos)
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/alunos/{aluno_id}", response_model=Dict)
def visualizar_perfil(aluno_id: int):
    return service.obter_perfil_aluno(aluno_id)

@router.get("/ranking", response_model=List[Dict])
def listar_ranking():
    return service.obter_ranking_geral()