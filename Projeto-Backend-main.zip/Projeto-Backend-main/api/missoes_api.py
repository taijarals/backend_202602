from fastapi import APIRouter, HTTPException
from typing import List, Dict
from models.missoes_entities import Missao, Etapa
from services.missoes_service import MissoesService
from pydantic import BaseModel

router = APIRouter(prefix="/missoes", tags=["Missões Educacionais"])
service = MissoesService()

class PayloadCriarJornada(BaseModel):
    missao: Missao
    etapas: List[Etapa]

@router.post("/", response_model=Dict)
def criar_missao_com_etapas(payload: PayloadCriarJornada):
    try:
        return service.criar_jornada(payload.missao, payload.etapas)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/", response_model=List[Dict])
def listar_missoes():
    return service.listar_jornadas_disponiveis()

@router.post("/progresso")
def concluir_etapa(aluno_id: int, missao_id: int, etapa_id: int):
    try:
        return service.concluir_etapa(aluno_id, missao_id, etapa_id)
    except ValueError as e:
        raise HTTPException(status_code=403, detail=str(e))

@router.get("/status")
def status_jornada(aluno_id: int, missao_id: int):
    return service.verificar_status_missao(aluno_id, missao_id)