from fastapi import APIRouter, HTTPException
from typing import List, Dict
from models.provas_entities import Prova, Questao, Tentativa, SubmissaoProva
from services.provas_service import ProvaService

router = APIRouter(prefix="/mini-provas", tags=["Mini-Provas"])
service = ProvaService()

class PayloadCriarProva(Prova):
    questoes: List[Questao]

@router.post("/", response_model=Dict)
def criar_prova_completa(payload: PayloadCriarProva):
    try:
        prova = Prova(titulo=payload.titulo, professor_id=payload.professor_id)
        return service.criar_prova_com_questoes(prova, payload.questoes)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/", response_model=List[Dict])
def listar_provas():
    return service.listar_todas_provas()

@router.post("/tentativas/")
def iniciar_prova(prova_id: int, aluno_id: int):
    try:
        return service.iniciar_tentativa(prova_id, aluno_id)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/{prova_id}/questoes")
def listar_questoes_aluno(prova_id: int):
    return service.obter_questoes_para_aluno(prova_id)

@router.post("/submissoes/")
def corrigir_prova(submissao: SubmissaoProva):
    try:
        return service.submeter_prova_e_corrigir(submissao)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))