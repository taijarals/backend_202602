from fastapi import APIRouter, HTTPException
from typing import List, Dict
from models.equipas_entities import ConfiguracaoSorteio
from services.equipas_service import EquipasService

router = APIRouter(prefix="/equipas", tags=["Formação de Equipas"])
service = EquipasService()

@router.post("/gerar", response_model=List[Dict])
def gerar_equipas(config: ConfiguracaoSorteio):
    try:
        return service.gerar_equipas_automaticamente(config)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@router.get("/", response_model=List[Dict])
def listar_equipas():
    return service.obter_equipas_atuais()

@router.get("/alunos", response_model=List[Dict])
def listar_alunos():
    return service.obter_perfis_alunos()