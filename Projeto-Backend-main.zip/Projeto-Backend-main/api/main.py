from fastapi import FastAPI, HTTPException
from typing import List
from models.entities import Desafio, Submissao, Voto, RankingItem
from services.desafio_service import DesafioService

app = FastAPI(title="Plataforma Educacional - Módulo 1 (Desafios)")
service = DesafioService()

@app.post("/desafios/", response_model=dict)
def criar_desafio(desafio: Desafio):
    return service.criar_novo_desafio(desafio)

@app.get("/desafios/", response_model=List[dict])
def listar_desafios():
    return service.obter_todos_desafios()

@app.post("/submissoes/", response_model=dict)
def enviar_submissao(sub: Submissao):
    return service.enviar_resposta(sub)

@app.post("/votos/", response_model=dict)
def votar(voto: Voto):
    try:
        return service.votar_submissao(voto)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

@app.get("/desafios/{desafio_id}/ranking", response_model=List[dict])
def obter_ranking(desafio_id: int):
    return service.gerar_ranking(desafio_id)