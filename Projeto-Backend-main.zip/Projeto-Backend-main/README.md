# 🚀 Como Executar o Projeto Localmente

Este guia descreve os passos necessários para configurar e executar a Plataforma Educacional (Backend em FastAPI e Frontend em Streamlit) na sua máquina local.

## Pré-requisitos
Certifique-se de ter o **Python 3.8+** instalado na sua máquina.

## Passo a Passo

**1. Clone o repositório ou navegue até a pasta do projeto**
Abra o seu terminal e navegue até a pasta raiz do projeto, onde se encontram o arquivo `requirements.txt` e as pastas `api/` e `pages/`.

**2. Crie e ative um ambiente virtual**
O ambiente virtual isola as dependências do projeto da sua máquina. No terminal, execute:
- Para criar o ambiente:
  `python -m venv venv`
- Para ativar no **Windows**:
  `venv\Scripts\activate`
- Para ativar no **Mac/Linux**:
  `source venv/bin/activate`

*(Você saberá que funcionou se o prefixo `(venv)` aparecer no início da linha de comando do seu terminal).*

**3. Instale as dependências**
Com o ambiente virtual ativado, instale todas as bibliotecas necessárias listadas no arquivo do projeto:
`pip install -r requirements.txt`

**4. Inicie o Servidor Backend (FastAPI)**
O backend gerencia as regras de negócio e os dados. No mesmo terminal, execute o seguinte comando:
`uvicorn api.main:app --reload`
O servidor iniciará e ficará rodando no endereço `http://127.0.0.1:8000`. **Deixe este terminal aberto.**

**5. Inicie a Interface Frontend (Streamlit)**
Para interagir com o sistema, precisamos iniciar o frontend em um segundo terminal. Siga estes passos:
- Abra uma **nova aba ou janela** de terminal.
- Navegue novamente até a pasta raiz do projeto.
- Ative o ambiente virtual neste novo terminal (`venv\Scripts\activate` ou `source venv/bin/activate`).
- Execute o comando para iniciar a interface:
  `streamlit run pages/app.py`
*(Nota: Se quiser testar um módulo específico que não esteja centralizado no app.py, basta trocar o nome do arquivo, ex: `streamlit run pages/missoes_app.py`)*.

Após rodar o comando do Streamlit, uma aba será aberta automaticamente no seu navegador padrão (geralmente em `http://localhost:8501`), conectada ao seu backend local. Pronto, você já pode testar o sistema!