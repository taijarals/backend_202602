from providers.factory import ProviderFactory

class DesafioRepository:
    def __init__(self):
        self.db_desafios = ProviderFactory.create("mock")
        self.db_submissoes = ProviderFactory.create("mock")
        self.db_votos = ProviderFactory.create("mock")

    # --- Desafios ---
    def criar_desafio(self, desafio_dict):
        # Simulando auto-incremento de ID
        desafio_dict["id"] = len(self.db_desafios.get_all()) + 1
        return self.db_desafios.create(desafio_dict)

    def listar_desafios(self):
        return self.db_desafios.get_all()

    # --- Submissões ---
    def criar_submissao(self, sub_dict):
        sub_dict["id"] = len(self.db_submissoes.get_all()) + 1
        return self.db_submissoes.create(sub_dict)

    def listar_submissoes_por_desafio(self, desafio_id: int):
        todas = self.db_submissoes.get_all()
        return [s for s in todas if s["desafio_id"] == desafio_id]

    # --- Votos e Notas ---
    def registrar_voto(self, voto_dict):
        voto_dict["id"] = len(self.db_votos.get_all()) + 1
        return self.db_votos.create(voto_dict)

    def listar_votos_por_submissao(self, submissao_id: int):
        todos = self.db_votos.get_all()
        return [v for v in todos if v["submissao_id"] == submissao_id]