from providers.factory import ProviderFactory

class GamificacaoRepository:
    def __init__(self):
        self.db_historico = ProviderFactory.create("mock")
        self.db_perfis = ProviderFactory.create("mock")
        self.db_medalhas = ProviderFactory.create("mock")
        
        # Inicialização de medalhas padrão no sistema
        self._seed_medalhas()

    def _seed_medalhas(self):
        if not self.db_medalhas.get_all():
            self.db_medalhas.create({"id": 1, "nome": "Iniciante", "descricao": "Primeiros 50 pontos!", "icone": "🥉", "pontos_minimos": 50})
            self.db_medalhas.create({"id": 2, "nome": "Esforçado", "descricao": "Atingiu 200 pontos!", "icone": "🥈", "pontos_minimos": 200})
            self.db_medalhas.create({"id": 3, "nome": "Mestre", "descricao": "Atingiu 500 pontos!", "icone": "🥇", "pontos_minimos": 500})

    def registrar_pontos(self, historico_dict: dict):
        historico_dict["id"] = len(self.db_historico.get_all()) + 1
        return self.db_historico.create(historico_dict)

    def obter_historico_aluno(self, aluno_id: int):
        return [h for h in self.db_historico.get_all() if h["aluno_id"] == aluno_id]
        
    def obter_todas_medalhas(self):
        return self.db_medalhas.get_all()

    def obter_perfil(self, aluno_id: int):
        for p in self.db_perfis.get_all():
            if p["aluno_id"] == aluno_id:
                return p
        # Se não existir, cria um perfil inicial
        novo_perfil = {
            "aluno_id": aluno_id, "pontos_totais": 0, "nivel_atual": 1, 
            "streak_dias": 0, "ultima_atividade": None, "medalhas": []
        }
        return self.db_perfis.create(novo_perfil)

    def atualizar_perfil(self, aluno_id: int, atualizacoes: dict):
        perfil = self.obter_perfil(aluno_id)
        perfil.update(atualizacoes)
        return perfil
        
    def listar_todos_perfis(self):
        return self.db_perfis.get_all()