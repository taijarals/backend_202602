from providers.factory import ProviderFactory
from models.equipas_entities import PerfilHabilidade

class EquipasRepository:
    def __init__(self):
        self.db_equipas = ProviderFactory.create("mock")
        self.db_perfis = ProviderFactory.create("mock")
        self._seed_perfis()

    def _seed_perfis(self):
        # Injetar dados fictícios para podermos testar o algoritmo de imediato
        if not self.db_perfis.get_all():
            alunos_mock = [
                {"aluno_id": 1, "nome_aluno": "Ana Silva", "habilidade_principal": "Programação", "pontuacao_desempenho": 95.0},
                {"aluno_id": 2, "nome_aluno": "Bruno Costa", "habilidade_principal": "Design", "pontuacao_desempenho": 60.0},
                {"aluno_id": 3, "nome_aluno": "Carlos Dias", "habilidade_principal": "Liderança", "pontuacao_desempenho": 85.0},
                {"aluno_id": 4, "nome_aluno": "Diana Lima", "habilidade_principal": "Comunicação", "pontuacao_desempenho": 45.0},
                {"aluno_id": 5, "nome_aluno": "Eduardo Pinto", "habilidade_principal": "Programação", "pontuacao_desempenho": 75.0},
                {"aluno_id": 6, "nome_aluno": "Filipa Mendes", "habilidade_principal": "Design", "pontuacao_desempenho": 90.0},
                {"aluno_id": 7, "nome_aluno": "Gonçalo Rocha", "habilidade_principal": "Comunicação", "pontuacao_desempenho": 55.0},
                {"aluno_id": 8, "nome_aluno": "Helena Neves", "habilidade_principal": "Liderança", "pontuacao_desempenho": 80.0},
            ]
            for a in alunos_mock:
                self.db_perfis.create(a)

    def obter_todos_perfis(self):
        return self.db_perfis.get_all()

    def guardar_equipa(self, equipa_dict: dict):
        equipa_dict["id"] = len(self.db_equipas.get_all()) + 1
        return self.db_equipas.create(equipa_dict)

    def listar_equipas(self):
        return self.db_equipas.get_all()

    def limpar_equipas(self):
        # Necessário para a funcionalidade de "Reorganização"
        self.db_equipas._data = []