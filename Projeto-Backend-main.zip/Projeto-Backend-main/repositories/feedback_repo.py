from providers.factory import ProviderFactory

class FeedbackRepository:
    def __init__(self):
        self.db_enquetes = ProviderFactory.create("mock")
        self.db_respostas = ProviderFactory.create("mock")

    # --- Enquetes (Sondagens) ---
    def criar_enquete(self, enquete_dict: dict):
        enquete_dict["id"] = len(self.db_enquetes.get_all()) + 1
        
        # Gerar IDs sequenciais para as perguntas e opções para facilitar a referência
        p_id_counter = 1
        o_id_counter = 1
        for p in enquete_dict["perguntas"]:
            p["id"] = p_id_counter
            p_id_counter += 1
            for o in p["opcoes"]:
                o["id"] = o_id_counter
                o_id_counter += 1
                
        return self.db_enquetes.create(enquete_dict)

    def obter_todas_enquetes(self):
        return self.db_enquetes.get_all()

    def obter_enquete(self, enquete_id: int):
        for e in self.db_enquetes.get_all():
            if e["id"] == enquete_id:
                return e
        return None

    def atualizar_status_enquete(self, enquete_id: int, ativa: bool):
        enquete = self.obter_enquete(enquete_id)
        if enquete:
            enquete["ativa"] = ativa
        return enquete

    # --- Respostas ---
    def registar_resposta(self, resposta_dict: dict):
        resposta_dict["id"] = len(self.db_respostas.get_all()) + 1
        return self.db_respostas.create(resposta_dict)

    def obter_respostas_por_enquete(self, enquete_id: int):
        return [r for r in self.db_respostas.get_all() if r["enquete_id"] == enquete_id]