from providers.factory import ProviderFactory

class MissoesRepository:
    def __init__(self):
        self.db_missoes = ProviderFactory.create("mock")
        self.db_etapas = ProviderFactory.create("mock")
        self.db_progresso = ProviderFactory.create("mock")

    # --- Missões e Etapas ---
    def guardar_missao(self, missao_dict: dict):
        missao_dict["id"] = len(self.db_missoes.get_all()) + 1
        return self.db_missoes.create(missao_dict)

    def guardar_etapa(self, etapa_dict: dict):
        etapa_dict["id"] = len(self.db_etapas.get_all()) + 1
        return self.db_etapas.create(etapa_dict)

    def obter_todas_missoes(self):
        return self.db_missoes.get_all()

    def obter_etapas_por_missao(self, missao_id: int):
        etapas = [e for e in self.db_etapas.get_all() if e["missao_id"] == missao_id]
        return sorted(etapas, key=lambda x: x["ordem"])

    # --- Progresso ---
    def registar_conclusao_etapa(self, progresso_dict: dict):
        progresso_dict["id"] = len(self.db_progresso.get_all()) + 1
        return self.db_progresso.create(progresso_dict)

    def obter_progresso_aluno(self, aluno_id: int, missao_id: int):
        return [p for p in self.db_progresso.get_all() if p["aluno_id"] == aluno_id and p["missao_id"] == missao_id]