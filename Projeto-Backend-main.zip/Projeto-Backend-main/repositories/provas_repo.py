from providers.factory import ProviderFactory

class ProvaRepository:
    def __init__(self):
        self.db_provas = ProviderFactory.create("mock")
        self.db_questoes = ProviderFactory.create("mock")
        self.db_tentativas = ProviderFactory.create("mock")

    # --- Provas e Questões ---
    def criar_prova(self, prova_dict: dict):
        prova_dict["id"] = len(self.db_provas.get_all()) + 1
        return self.db_provas.create(prova_dict)

    def listar_provas(self):
        return self.db_provas.get_all()

    def adicionar_questao(self, questao_dict: dict):
        questao_dict["id"] = len(self.db_questoes.get_all()) + 1
        return self.db_questoes.create(questao_dict)

    def listar_questoes_por_prova(self, prova_id: int):
        return [q for q in self.db_questoes.get_all() if q["prova_id"] == prova_id]

    # --- Tentativas e Respostas ---
    def registrar_tentativa(self, tentativa_dict: dict):
        tentativa_dict["id"] = len(self.db_tentativas.get_all()) + 1
        return self.db_tentativas.create(tentativa_dict)

    def obter_tentativa(self, tentativa_id: int):
        for t in self.db_tentativas.get_all():
            if t["id"] == tentativa_id:
                return t
        return None

    def atualizar_tentativa(self, tentativa_id: int, atualizacoes: dict):
        tentativa = self.obter_tentativa(tentativa_id)
        if tentativa:
            tentativa.update(atualizacoes)
        return tentativa